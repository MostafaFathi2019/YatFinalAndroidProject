package com.example.yatfinalproject;

public interface onFavoriteItemListner {
    void onFavoriteItemListner(String filmName,String filmImage,boolean isFavor);

}
